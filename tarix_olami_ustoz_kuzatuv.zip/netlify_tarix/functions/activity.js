const { getStore } = require("@netlify/blobs");
const crypto = require("crypto");

const json = (statusCode, body) => ({
  statusCode,
  headers: {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "Access-Control-Allow-Origin": process.env.URL ? process.env.URL : "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  },
  body: JSON.stringify(body)
});

exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") return json(204, {});
  if (event.httpMethod !== "POST") return json(405, { error: "Faqat POST so‘rovi ruxsat etiladi." });

  let payload;
  try { payload = JSON.parse(event.body || "{}"); }
  catch { return json(400, { error: "So‘rov formati noto‘g‘ri." }); }

  const store = getStore("tarix-olami-audit");
  if (payload.action === "read") {
    const secret = process.env.TEACHER_SESSION_SECRET || process.env.TEACHER_PASSWORD;
    if (!process.env.TEACHER_PASSWORD || !secret) return json(503, { error: "Netlify Environment variables ichida TEACHER_PASSWORD va TEACHER_SESSION_SECRET sozlanmagan." });
    const cookieHeader = event.headers.cookie || event.headers.Cookie || "";
    const cookie = cookieHeader.split(";").map(x => x.trim()).find(x => x.startsWith("hist_teacher_session="));
    const token = cookie ? decodeURIComponent(cookie.slice("hist_teacher_session=".length)) : "";
    const parts = token.split(".");
    const issued = parts[0] || "";
    const expected = crypto.createHmac("sha256", secret).update(issued).digest("hex");
    const age = Date.now() - Number(issued);
    const valid = /^\d{13}$/.test(issued) && age >= 0 && age <= 8 * 60 * 60 * 1000 && parts[1] && parts[1].length === expected.length && crypto.timingSafeEqual(Buffer.from(parts[1]), Buffer.from(expected));
    if (!valid) return json(401, { error: "Ustoz sessiyasi yo‘q yoki muddati tugagan. Ustoz sifatida qayta kiring." });
    try {
      const events = await store.get("events", { type: "json" }) || [];
      return json(200, { events });
    } catch {
      return json(200, { events: [] });
    }
  }

  const incoming = payload.event;
  if (!incoming || typeof incoming !== "object" || !String(incoming.action || "")) {
    return json(400, { error: "Harakat ma’lumoti yetishmaydi." });
  }

  const allowed = new Set([
    "kirish", "qayta_kirish", "chiqish", "mavzu_ochildi",
    "test_boshlandi", "savolga_javob", "test_topshirildi", "faollik_belgisi"
  ]);
  if (!allowed.has(incoming.action)) return json(400, { error: "Noma’lum harakat turi." });

  const eventRecord = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
    timestamp: new Date().toISOString(),
    clientTime: String(incoming.clientTime || "").slice(0, 50),
    username: String(incoming.username || "Noma’lum").slice(0, 120),
    role: ["student", "teacher"].includes(incoming.role) ? incoming.role : "unknown",
    sessionId: String(incoming.sessionId || "").slice(0, 100),
    action: incoming.action,
    page: String(incoming.page || "").slice(0, 200),
    details: incoming.details && typeof incoming.details === "object" ? incoming.details : {}
  };

  // Keep the audit store bounded. Store only the latest 10,000 activity records.
  try {
    const events = await store.get("events", { type: "json" }) || [];
    events.push(eventRecord);
    await store.setJSON("events", events.slice(-10000));
    return json(200, { ok: true, id: eventRecord.id, timestamp: eventRecord.timestamp });
  } catch (error) {
    return json(500, { error: "Faollik jurnaliga yozib bo‘lmadi. Netlify Blobs sozlamasini tekshiring." });
  }
};
