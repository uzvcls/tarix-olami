const crypto = require("crypto");
const json = (statusCode, body, extraHeaders = {}) => ({
  statusCode, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...extraHeaders }, body: JSON.stringify(body)
});
function sign(value, secret) { return crypto.createHmac("sha256", secret).update(value).digest("hex"); }
exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return json(405, { error: "Faqat POST so‘rovi ruxsat etiladi." });
  let body;
  try { body = JSON.parse(event.body || "{}"); } catch { return json(400, { error: "So‘rov noto‘g‘ri." }); }
  if (body.action === "logout") {
    return json(200, { ok: true }, { "Set-Cookie": "hist_teacher_session=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0" });
  }
  const password = process.env.TEACHER_PASSWORD;
  const secret = process.env.TEACHER_SESSION_SECRET || password;
  if (!password || !secret) return json(503, { error: "Netlify'da TEACHER_PASSWORD va TEACHER_SESSION_SECRET sozlang." });
  if (String(body.password || "") !== password) return json(401, { error: "Ustoz paroli noto‘g‘ri." });
  const issued = String(Date.now());
  const token = `${issued}.${sign(issued, secret)}`;
  return json(200, { ok: true }, { "Set-Cookie": `hist_teacher_session=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=28800` });
};
